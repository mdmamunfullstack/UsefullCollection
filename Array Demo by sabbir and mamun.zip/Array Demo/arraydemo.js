
//var colors=  ['red', 'hellow', 'blue']
//1. Array Check
// const colors = Array.of('red', 'hellow', 'blue');


// console.log(colors);
// console.log(colors instanceof Array);
// console.log(Array.isArray(colors));


//2. Array Check
/*
function doit() {
  console.log(arguments);
  console.log(arguments instanceof Array);

  var colors = Array.from(arguments);
  console.log(colors instanceof Array);
  
}

doit(1,2,3)
*/


//rest oparator
// var nums =[1,2,3,4,5,6]
// const [first, second, ...remaining]= nums; 

//console.log(first, second,remaining)

//shift and unshift
/*
var colors=  ['red', 'hellow', 'blue']
var newLen = colors.unshift('orange');
var removeElement = colors.shift();
console.log(newLen);


console.log(removeElement);
*/


//splice

// var colors=  ['red', 'hellow', 'blue']
// var splice =colors.splice(1,2,'green');
// var fruits = ["Banana", "Orange", "Apple", "Mango"];
// var splice = fruits.splice(2,0,"Lemon", "Kiwi")

// colors.reverse()
// console.log(colors);



//Sort
/*
const people = [
  { id: 3, fn: 'Bob', ln: 'Smith' },
  { id: 1, fn: 'Tim', ln: 'Smith' },
  { id: 2, fn: 'Jane', ln: 'Smith' },
];

people.sort((a,b)=>{
  return a.id -b.id;
})

console.log(people)
*/


//Array Loop
/*
var colors=  ['red', 'hellow', 'blue']
for (let index = 0; index < colors.length; index++) {
  console.log('index : '+index, 'color : '+ colors[index]);
  
}
*/

//entries
/*
var colors=  ['red', 'hellow', 'blue']
for (const [index, value] of colors.entries()) {
  console.log('index : '+index, 'color : '+ colors[index]);
  
}
*/

//concate
/*
const orginalNums= [1,2,3,4,5];
const newNums = orginalNums.concat(6,7,8)

//const newNums = orginalNums.concat([5,6,7,8])
*/

//slice - The slice() method returns the selected elements in an array, as a new array object.
const orginalNums= [1,2,3,4,5];
const newNums = orginalNums.slice(1,5)

//filter -
/*
const colors = [ 'red', 'yellow', 'blue', 'green' ];

const filteredColors = colors.filter( (color, index, arr) => {
    console.log(color, index, arr);
    return color.length > 3;
} );
*/

/*
Array.prototype.helloWorld = () => 
{

  console.log('All Array will have this new property')
}

colors.helloWorld();

Array.prototype.fooFilter = function(checkElement) {
   const returnArr =[];

   for (let index = 0; index < this.length; index++) {
       if(checkElement(this[index])){
        returnArr.push(this[index]);
       }
     
   }

   return returnArr;
};



const arr = [1,3,5,6,9,11,26,8,35,10,7,42,88];
console.log(arr.fooFilter(x => x % 2 === 0)); // [6,26,8,10,42,88]
*/


//include, some
/*
const arr = [1,3,5,6,9,11,26,8,35,10,7,42,88];

console.log(arr.includes(2))
console.log(arr.includes(9))


console.log(arr.some(n => n>2));
*/



//join
/*
const arr = [1,3,5,6,9,11,26,8,35,10,7,42,88];

console.log(arr.join('-'));
*/




/*
const people = [
  { id: 1, name: 'Bob' },
  { id: 2, name: 'Jane' },
  { id: 3, name: 'Tim' },
];


// const newUserArray = users.filter(user=> user.name != 'Samir');
// console.log(newUserArray)
var personIndex = people.findIndex( (person, index, arr) => {
        console.log(person, index, arr);
        return person.id === 2;
    });
    console.log(personIndex);
*/




